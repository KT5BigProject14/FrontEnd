// components/HeavyComponent.js
const HeavyComponent = () => {
    return <div>This is a heavy component.</div>;
  };
  
  export default HeavyComponent;